package featherclient;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import featherclient.ui.ClickGUI;

public class APGClientFeather implements ModInitializer {
    public static boolean showFPS = true;
    public static int hudColor = 0x00FFFF; 
    public static boolean isEditorOpen = false;

    @Override
    public void onInitialize() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (client.options.rightControlKey.wasPressed()) {
                client.setScreen(new ClickGUI()); // Aapka apna Menu khulega
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.options.hudHidden) return;

            // --- YAHAN NAAM BADLA HAI ---
            drawContext.drawText(client.textRenderer, "§6§lAHMAD CLIENT §f| §7v1.0", 10, 10, 0xFFFFFF, true);
            
            if (showFPS) {
                String fps = "FPS: " + client.getCurrentFps();
                drawContext.drawText(client.textRenderer, fps, 10, 25, hudColor, true);
            }
        });
    }
}